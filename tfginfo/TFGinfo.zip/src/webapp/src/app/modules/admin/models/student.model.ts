import { CareerDTO } from "./career.model";

export interface StudentBase {
    id?: number;
    name: string;
    surname: string;
    email: string;
    dni: string;
    phone?: string;
    address?: string;
    birthdate?: Date;
}

export interface StudentDTO extends StudentBase {
    career: CareerDTO;
}

export interface NewStudentDTO {
    student: StudentDTO;
    auth_code: string;
}

export interface StudentFlatDTO extends StudentBase {
    careerId: number;
}

export interface StudentOptionalData {
    phone?: string;
    address?: string;
    birthdate?: Date;
}

export interface CareerBase {
    id: number;
    name: string;
}